import React, { useState } from 'react';

const LoginScreen = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const handleLogin = async () => {
    // Enviar as credenciais para o servidor
    const response = await fetch('/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ username, password })
    });

    const data = await response.json();
    
    // Verificar a resposta do servidor
    if (data.success) {
      setIsLoggedIn(true);
    } else {
      setIsLoggedIn(false);
    }
  };

  if (isLoggedIn) {
    // Redirecionar para a página de listagem de professores ou alunos
    // Implemente o redirecionamento de acordo com as suas necessidades
    return <Redirect to="/listagem" />;
  }

  return (
    <div>
      <h2>Login</h2>
      <input
        type="text"
        placeholder="Username"
        value={username}
        onChange={e => setUsername(e.target.value)}
      />
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={e => setPassword(e.target.value)}
      />
      <button onClick={handleLogin}>Login</button>
    </div>
  );
};

export default LoginScreen;