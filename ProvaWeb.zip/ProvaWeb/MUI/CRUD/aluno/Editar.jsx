import { Typography, TextField, Box, Button } from "@mui/material"
import { useEffect } from "react"
import { useState } from "react"
import { useParams, useNavigate } from "react-router-dom"
import axios from "axios"

const Editar = () => {

    let { id } = useParams()
    const navigate = useNavigate()

    const [nome, setNome] = useState("")
    const [curso, setCurso] = useState("")
    const [ira, setIra] = useState()
    

    // como [] está vazio, o useEffect funciona como um construtor!
    useEffect(
        () => {
            axios.get(`http://localhost:3001/aluno/retrieve/${id}`)
            .then(
                (response) => {
                    setNome(response.data.nome)
                    setCurso(response.data.curso)
                    setIra(response.data.ira)
                }
            )
            .catch(error => console.log(error))
        },
        []
    )

    function handleSubmit(event) {
        event.preventDefault()
        // alert("Seu Cadastro foi Editado!")
        const alunoAtualizado = {nome, curso, ira}
        axios.put(`http://localhost:3001/aluno/update/${id}`, alunoAtualizado)
        .then(
            (response) => {
                alert(`Aluno ID ${response.data._id} atualizado`)
                navigate("/listarAluno")
            }
        )
        .catch(error => console.log(error))
    }

    return (
        <>
            <Typography variant="h5" fontWeight="bold">
                Editar Aluno
            </Typography>
            <Box
                component="form"
                onSubmit={handleSubmit}
            >
                <TextField
                    margin="normal"
                    required
                    autoFocus
                    fullWidth
                    id="nome"
                    name="nome"
                    label="Nome Completo"
                    value={nome}
                    onChange={(event) => setNome(event.target.value)}
                />
    
                <TextField
                    margin="normal"
                    required
                    fullWidth
                    id="curso"
                    name="curso"
                    label="Curso"
                    value={curso}
                    onChange={(event) => setCurso(event.target.value)}
                />

                <TextField
                    margin="normal"
                    required
                    fullWidth
                    id="ira"
                    name="ira"
                    label="IRA"
                    type="number"
                    inputProps={{
                        maxLenght: 10,
                        step: "0.1"
                    }}
                    onChange={(event) => setIra(event.target.value)}
                />

                <FormControl fullWidth sx={{mt:2}}>
                    <InputLabel id="select-tit-label">Titulação</InputLabel>
                    <Select
                        labelId="select-tit-label"
                        label="Titulação"
                        value={titulacao}
                        onChange={(event) => setTitulacao(event.target.value)}
                    >
                        <MenuItem value="GRAD">Graduação</MenuItem>
                        <MenuItem value="MEST">Mestrado</MenuItem>
                        <MenuItem value="DOUT">Doutorado</MenuItem>
                    </Select>
                </FormControl>
                
                <Box sx={{display:"flex", justifyContent:"start"}}>
                    <Button
                        type="submit"
                        variant="contained"
                        sx={{my:3}}
                    >
                        Editar
                    </Button>
                </Box>
               
            </Box>
        </>
    )
}

export default Editar