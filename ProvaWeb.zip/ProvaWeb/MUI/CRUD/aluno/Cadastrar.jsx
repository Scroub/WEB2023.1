import { Typography, TextField, Box, FormControl, InputLabel, Select, MenuItem, Button } from "@mui/material"

import { useState } from "react"
import axios from "axios"
import { useNavigate } from "react-router-dom"

const Cadastrar = () => {

    const [nome, setNome] = useState("")
    const [curso, setCurso] = useState("")
    const [c, setC] = useState("")
    const [ira, setIra] = useState()

    const navigate = useNavigate()

    function handleSubmit(event) {
        event.preventDefault()
        alert("Cadastrado!")

        const novoAluno = {nome, curso, ira, c}
        axios.post("http://localhost:3001/aluno/inserir", novoAluno)
        .then(
            (response) => {
                alert(`Aluno ID ${response.data._id} adicionado!`)
                navigate("/listarAluno")
            }
        )
        .catch(error => console.log(error))
    }
    // No Curso Designado criamos valores para o menu e atribuimos o value de acordo com o que é selecionado
    // Quando ha uma mudança onChange ele altera o valor
    return (
        <>
            <Typography variant="h5" fontWeight="bold">
                Cadastrar Aluno
            </Typography>
            <Box
                component="form"
                onSubmit={handleSubmit}
            >
                <TextField
                    margin="normal"
                    required
                    autoFocus
                    fullWidth
                    id="nome"
                    name="nome"
                    label="Nome Completo"
                    onChange={(event) => setNome(event.target.value)}
                />
    
                <TextField
                    margin="normal"
                    required
                    fullWidth
                    id="curso"
                    name="curso"
                    label="Curso"
                    onChange={(event) => setCurso(event.target.value)}
                />

                <TextField
                    margin="normal"
                    required
                    fullWidth
                    id="ira"
                    name="ira"
                    label="IRA"
                    type="number"
                    inputProps={{
                        maxLenght: 10,
                        step: "0.1"
                    }}
                    onChange={(event) => setIra(event.target.value)}
                />

                <FormControl fullWidth sx={{mt:2}}>
                    <InputLabel id="select-tit-label">Curso Designado</InputLabel>
                    <Select
                        labelId="select-tit-label"
                        label="Curso Designado"
                        value={c}
                        onChange={(event) => setC(event.target.value)}
                    >
                        <MenuItem value="DD">Design Digital</MenuItem>
                        <MenuItem value="SI">Sistemas de Informação</MenuItem>
                        <MenuItem value="CC">Ciencia da Computação</MenuItem>
                        <MenuItem value="ES">Engenharia de Software</MenuItem>
                        <MenuItem value="EC">Engenharia da Computação</MenuItem>
                        <MenuItem value="RC">Redes de Computadores</MenuItem>
                    </Select>
                </FormControl>


                <Box sx={{display:"flex", justifyContent:"start"}}>
                    <Button
                        type="submit"
                        variant="contained"
                        sx={{my:3}}
                    >
                        Cadastrar
                    </Button>
                </Box>
               
            </Box>
        </>
    )
}

export default Cadastrar
