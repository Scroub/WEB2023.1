import { Typography, TableContainer, Paper, Table, TableHead, TableBody, TableRow, TableCell, Box } from "@mui/material"
import IconButton from "@mui/material/IconButton"
import DeleteIcon  from "@mui/icons-material/Delete"
import EditIcon from "@mui/icons-material/Edit"
import { styled } from "@mui/material/styles"
import { tableCellClasses } from "@mui/material/TableCell"
import { Link } from "react-router-dom"
import { useEffect, useState } from "react"
import axios from "axios"

const Listar = () => {

    const [alunos, setAlunos] = useState ([])
    const [mudanca, setMudanca] = useState(false)
    const [media, setMedia] = useState()

    useEffect (
        () => {
            axios.get("http://localhost:3001/aluno/listar")
            .then(
                (response) => {
                    setAlunos(response.data)
                }
            )
            .catch(error => console.log(error))
        },
        []
    )

    function deleteTeste (id) {
        for(let i = 0; i < alunos.length; i++){
            if(alunos[i]._id == id) {
                alunos.splice(i, 1)
                return true
            }
        }
        return false
    }

    function deleteAlunoById(id) {
        if(window.confirm("Deseja Excluir?")){
            alert("Aluno " + id + " excluido com sucesso!")
            axios.delete(`http://localhost:3001/aluno/delete/${id}`)
            .then(
                (response) => {
                    deleteTeste(id)
                    setMudanca(!mudanca)
                }
            )
            .catch(error => console.log(error))
        }
    }

    function calcularMediaIra() {
        for (let i = 0; alunos.length; i++){
            media = alunos[i].ira
        }

    }


    return (
        <>
            <Typography variant="h5" fontWeight="bold">
                Listar Alunos
            </Typography>
            <TableContainer component={Paper} sx={{my: 4}}>
                <Table sx={{minWidth: 650}} arial-label="simple table">
                    <TableHead>
                        <TableRow>
                            <StyledTableCell>ID</StyledTableCell>
                            <StyledTableCell>NOME</StyledTableCell>
                            <StyledTableCell>CURSO</StyledTableCell>
                            <StyledTableCell>IRA</StyledTableCell>
                            <StyledTableCell>Media</StyledTableCell>
                            <StyledTableCell>AÇÕES</StyledTableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {
                            alunos.map(
                                (aluno) => {
                                    return (
                                        <StyledTableRow key={aluno._id}>
                                            <StyledTableCell>{aluno._id}</StyledTableCell>
                                            <StyledTableCell>{aluno.nome}</StyledTableCell>
                                            <StyledTableCell>{aluno.curso}</StyledTableCell>
                                            <StyledTableCell>{aluno.ira}</StyledTableCell>
                                            <StyledTableCell>{aluno.media}</StyledTableCell>
                                            <StyledTableCell>
                                                <Box>
                                                    <IconButton aria-label="edit" color="primary" component={Link} to={`/editarAluno/${aluno._id}`}>
                                                        <EditIcon />
                                                    </IconButton>
                                                    <IconButton aria-label="delete" color="error" onClick={() => deleteAlunoById(aluno._id)}>
                                                        <DeleteIcon />
                                                    </IconButton>
                                                </Box>
                                            </StyledTableCell>
                                        </StyledTableRow>
                                    )            
                                }
                            )
                        }
                    </TableBody>
                </Table>

            </TableContainer>
        </>
    )
}

const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
        backgroundColor: theme.palette.common.black,
        color: theme.palette.common.white,
    },
    [`&.${tableCellClasses.body}`]: {
        fontSize: 14,
    },
}));


const StyledTableRow = styled(TableRow)(({ theme }) => ({
    '&:nth-of-type(odd)': {
        backgroundColor: theme.palette.action.hover,
    },
    '&:last-child td, &:last-child th': {
        border:0,
    },
}));

export default Listar