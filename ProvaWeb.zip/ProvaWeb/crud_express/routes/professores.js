var express = require('express');
var router = express.Router();
var ProfessorService = require("../services/professor.services")
var professorServiceMongo = require("../services/professor.services.mongo")

/*router.get(
    "/listar", 
    (req, res, next) => {
        res.json(ProfessorService.list())
    }
)*/

router.get(
    "/listar", 
    (request, response, next) => {
        professorServiceMongo.list(request, response)
    }
)

/*router.post(
    "/inserir",
    (req, res, next) => {
        const professor = ProfessorService.register(req.body)
        res.json(professor)
    }
)*/

router.post(
    "/inserir",
    (request, response, next) => {
        professorServiceMongo.register(request, response)
    }
)


/*router.put(
    "/update/:id",
    (req, res, next) => {
        const professor = ProfessorService.update(req.params.id, req.body)
        res.json(professor)
    }
)*/

router.put(
    "/update/:id",
    (request, response, next) => {
        professorServiceMongo.update(request, response)
    }
)

/*router.delete(
    "/delete/:id",
    (req, res, next) => {
        const ok = ProfessorService.delete(req.params.id)
        if(ok) return res.json({ "sucess": true })
        else return res.json({ "sucess": false })
    }
)*/

router.delete(
    "/delete/:id",
    (request, response, next) => {
        professorServiceMongo.delete(request, response)
    }
)

/*router.get(
    "/retrieve/:id",
    (req, res, next) => {
        const out = ProfessorService.retrieve(req.params.id)
        return res.json(out)
    }
)*/

router.get(
    "/retrieve/:id",
    (request, response, next) => {
        professorServiceMongo.retrieve(request, response)
    }
)

module.exports = router;
